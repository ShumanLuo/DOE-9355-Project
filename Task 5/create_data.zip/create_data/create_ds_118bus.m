% This creates a dataset from powerflow simulations
%%
clear all;
close all;
clc;

%% Setting up data

% reading data
file_name = 'load_data.xlsx';

sheet_name = 'gmlc';
data_table = readtable(file_name,'Sheet',sheet_name);

[num_samples,~] = size(data_table);

data_array = table2array(data_table);

% normalizing data
load_factor = data_array ./ mean(sum(data_array,2));

%% Setting grid data

num_periods = num_samples;
% num_periods = 100;
case_name = 'case118';

load_bus_bounds = [0.95,1.05]; % bounds for load changing

mpc = loadcase(case_name);

[num_buses,~] = size(mpc.bus);
[num_branches,~] = size(mpc.branch);

mpopt = mpoption('verbose', 0, 'out.all', 0); %0 for not printing

success = zeros(num_periods,1);
pf_branches = zeros(num_branches, num_periods);
qf_branches = zeros(num_branches, num_periods);
voltage_magnitudes_b = zeros(num_buses, num_periods);
voltage_angles_b = zeros(num_buses, num_periods);

for t = 1:num_periods

    fprintf('Simulation [%d]\n',t);
    
    % active load ts
    mpc_mod = mpc;

    % changing both active and reactive power
    mpc_mod.bus(:,3:4) = mpc_mod.bus(:,3:4)*load_factor(t);
    
    % % adding noise to bus loads
    % load_random_factor = unifrnd(load_bus_bounds(1),load_bus_bounds(2),[num_buses 2]);
    % mpc_mod.bus(:,3:4) = mpc_mod.bus(:,3:4) .* load_random_factor;

    results = runpf(mpc_mod, mpopt);

    % getting results
    success_tmp = results.success;
    pf_branches_tmp = results.branch(:,14) / results.baseMVA;
    qf_branches_tmp = results.branch(:,15) / results.baseMVA;
    voltage_magnitude_tmp = results.bus(:,8);
    voltage_angle_tmp = results.bus(:,9);
    
    % saving results in arrays
    success(t) = success_tmp;
    pf_branches(:,t) = pf_branches_tmp*success_tmp;
    qf_branches(:,t) = qf_branches_tmp*success_tmp;
    voltage_magnitudes_b(:,t) = voltage_magnitude_tmp*success_tmp;
    voltage_angles_b(:,t) = voltage_angle_tmp*success_tmp;
end

voltage_complex = voltage_magnitudes_b .* exp(1j*voltage_angles_b*pi/180);

voltage_magnitudes = abs(voltage_complex);
voltage_angles = angle(voltage_complex);

[sum(success) num_periods]

%% Saving results

% setting data to save

% pf table [num_branches x num_samples]
col_names = "sim_" + [1:num_periods];
row_names = "pf_" + [1:num_branches];

pf_table = array2table(pf_branches,...
    'VariableNames',col_names);

% qf table [num_branches x num_samples]
qf_table = array2table(qf_branches,...
    'VariableNames',col_names);

% v_mag table [num_buses x num_samples]
v_mag_table = array2table(voltage_magnitudes,...
    'VariableNames',col_names);

% v_ang table [num_buses x num_samples]
v_ang_table = array2table(voltage_angles,...
    'VariableNames',col_names);

load_factor_table = array2table([[1:num_periods]' load_factor(1:num_periods) success],...
    'VariableNames',["#Sim" "Load_factor" "Success"]);

% Saving all in a xlsx file
file_name = ['ds_',case_name,'.xlsx'];
file_name = fullfile(file_name);

if isfile(file_name)
    delete(file_name)
end

writetable(pf_table,file_name,'Sheet','pf','WriteRowNames',true)
writetable(qf_table,file_name,'Sheet','qf','WriteRowNames',true)
writetable(v_mag_table,file_name,'Sheet','v_mag')
writetable(v_ang_table,file_name,'Sheet','v_ang')
writetable(load_factor_table,file_name,'Sheet','sim_info')
